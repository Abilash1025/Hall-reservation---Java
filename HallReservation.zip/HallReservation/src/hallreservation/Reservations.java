package hallreservation;

public class Reservations 
{
    private int first,last,length;
    private Reservedetails reservations[];  //the buffer
    public Reservedetails item;
    
    public Reservations()
    {
        this.length=first+1;
        this.first=-1;
        this.last=-1;
        reservations=new Reservedetails[length];
    }
    
    public boolean isEmpty()
    {
        return (first==-1);
    }
    
    public boolean isFull()
    {
        return (first==0&&last==length-1||first==last+1);
    }
    
    public void enqueue(String cName,String num,String mail,
            String loc,String date,int guests,int bId)
    {
            if(isEmpty()==true)
            {
                first=0;
            }
            last=(last+1)%length;
                      
            reservations[last]=new Reservedetails(cName,num,mail,loc,date,guests,bId);
            System.out.println("ID:"+reservations[last].id+" The banquet hall is reserved.");    
    }
    
    public Reservedetails dequeue(String cName,int id)
    {  
        item=null;
        
        if(isEmpty()!=true)
        {
            item=reservations[searchIndex(cName,id)];
            
            if(first!=last)
            {
                first=(first+1)%length;
            }
            
            {
                first=-1;
                last=-1;
            } 
        }
        else
        {
            System.out.println("The queue is empty.");
        }
        return item;     
    }
    
    public int searchIndex(String cName,int id)
    {
        for(int i=0;i<length;i++)
        {
            if(reservations[i].Customername.equals(cName)&&reservations[i].id==id)
            {
                return i;
            }
        }
        return -1;
    }
    
    public void displayQueue()
    {
        if(isEmpty()!=true)
        {
            for(first=0;first<length;first++)
            {            
                
                    System.out.println(reservations[first].toString()+"\n");
                
            }
        }
        else
        {
                System.out.println("There are no banquet hall reservations.");            
        }
    }
    
}
