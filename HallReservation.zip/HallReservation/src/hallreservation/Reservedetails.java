package hallreservation;

public class Reservedetails 
{
    public String Customername,ContactNum,EMail,location,date;
    public int id, Numberofguests;

    public Reservedetails(String Customername,String num,String mail,
            String location,String date,int Numberofguests,int bId)
    {
                this.Customername=Customername;
                this.ContactNum=num;
                this.EMail=mail;
                this.location=location;
                this.date=date;
                this.Numberofguests=Numberofguests;
                this.id=bId;
    }
    
    public String toString()
    {
        return "BanquetHall ID:"+id+" Location:"+location
                +" Reservation Date:"+date+" Number of Numberofguests:"+Numberofguests
                +" Customer Name:"+Customername+" Contact Number:"+ContactNum
                +" Mail Address:"+EMail;
    }
    
    public String rDetails()
    {
        return this.Customername+this.location+this.date+this.Numberofguests+this.id;
    }
}
