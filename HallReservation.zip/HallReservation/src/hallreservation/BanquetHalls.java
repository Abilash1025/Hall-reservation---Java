package hallreservation;

import java.util.Scanner;

public class BanquetHalls 
{
    private int last;
    public int first,length;
    public Halls Banquets[];  //the buffer

    
    public BanquetHalls()
    {
        this.length=10;
        this.first=-1;
        this.last=-1;
        Banquets=new Halls[length];
        
        if(first==-1)
        {
            first=0;
        }

        Banquets[0]= new Halls(101,"Topaz","Negombo",1200,1800,2000,100,"10/05/2019");
        Banquets[1]= new Halls(102,"Kreeptow","Negombo",1200,1800,2000,300,"10/05/2019");
        Banquets[2]= new Halls(103,"Browns","Negombo",1200,1800,2000,280,"10/05/2019");
        Banquets[3]= new Halls(104,"Rainbow","Negombo",1200,1800,2000,410,"10/05/2019");
        Banquets[4]= new Halls(105,"Bonys","Negombo",1200,1800,2000,620,"10/05/2019");
        Banquets[5]= new Halls(106,"Avenra","Negombo",1200,1800,2000,500,"10/05/2019");
        Banquets[6]= new Halls(107,"Romantic","Negombo",1200,1800,2000,750,"10/05/2019");
        Banquets[7]= new Halls(108,"TONY","Negombo",1200,1800,2000,50,"10/05/2019");
        Banquets[8]= new Halls(109,"Shield","Negombo",1200,1800,2000,900,"10/05/2019");
        Banquets[9]= new Halls(110,"ABI","Negombo",1200,1800,2000,850,"10/05/2019");
        
    }
    
    public boolean isEmpty()
    {
        if(first==-1)
        {
            return true;
        }
        return false;       
    }
    public boolean isFull()
    {
        return (first==0&&last==length-1||first==last+1);
    }
    public void enqueue()
    {
        
        if(isFull()!=true)//check if the queue is not full
        {
            
            if(isEmpty()==true)//check if the queue is empty.(first==-1;)
            {
                first=0;  
            }
            last=(last+1)%length;         
            Banquets[last]=null;  
            
        }
        else
        {
            System.out.println("Queue is full.");
        }
    }
    //delete the first element of the queue
    public Object dequeue()
    {
        Object item=null;
        
        if(isEmpty()!=true)  //check if the queue is not empty
        {
            item=Banquets[first];  
            
            if(first!=last) //queue has more than one element
            {
                
                first=(first+1)%length;
            }
            else
            {
                first=-1;
                last=-1;
            } 
        }
        else
        {
            System.out.println("The queue is empty.");
        }
        return item; 
    }  
    
    //display queue
    public void displayQueue()
    {
        for(last=length-1;last>=0;last--)
        {
            System.out.println("ID:"+Banquets[last]);
            System.out.println("_______________________________________________"
                    + "________________________________________________________");
        }
    }
    
    public void SetReserveid(int n)
    {
        if(Banquets[n].reserveId==0)
        {
            Scanner sc=new Scanner(System.in);            
            System.out.println("Enter Reservation Id: ");
            int reserveId=sc.nextInt();
                      
            Banquets[n].reserveId=reserveId;
            System.out.println(Banquets[n]);
        }
    }
    

    public int searchBHall(String nLoc,String nDate,int nGuests)
    {
        for(first=0;first<length;first++)
        {    
            if(Banquets[first].location.equals(nLoc) &&
                        Banquets[first].date.equals(nDate) &&
                        Banquets[first].maxGuests<=nGuests &&
                        Banquets[first].reserveId==0)
            { 
                System.out.println("Available Banquet Hall:\n"+Banquets[first].toString1());
                System.out.println(first);
                return first;
            }
            
        }
        return first;
    }
    
    public void avaiBanquetH()
        {
                for(int n=0;n<length;n++)
                {
                    if(Banquets[n].reserveId==0)
                    {
                        System.out.println("\n"+Banquets[n].toString1());
                    }

                }
        }
   
        
        public void bubble()
        {
            int n = Banquets.length;
        
            System.out.print("Unsorted Array\n");
            for(int i = 0; i < n; i++)
            {
                System.out.print(Banquets[i]+" ");
                System.out.println();
            }
            
            for(int i = 0; i < n-1; i++)
            {
                for(int j = 0; j < n-i-1; j++)
                {
                    Halls temp = Banquets[j];
                   
                    if(Banquets[j].maxGuests >Banquets[j+1].maxGuests)
                    {   
                        Banquets[j] = Banquets[j+1];
                        Banquets[j+1] = temp;
                    }
                    else
                    {
                        Banquets[j] = temp;
                    }
                }
            }
            
            System.out.print("\n\nSorted Array\n");
            
            for(int y = 0; y < Banquets.length; y++)
            {
                System.out.print("ID: "+Banquets[y].toString()+ " ");
                System.out.println();
            }
        }      
        public void Insertion(){
           System.out.print("Unsorted Array\n");
            for(int n = 0; n<Banquets.length; n++)
            {
                System.out.print(Banquets[n]+" ");
                System.out.println();
            }
      
        for(int i = 1; i < Banquets.length;++i){
            Halls temp=Banquets[i];
            int get = Banquets[i].maxGuests;
            int a=i-1;  
            
        while(a>=0 && Banquets[a].maxGuests>get){
                Banquets[a+1]=Banquets[a];
                a=a-1;
            }
        Banquets[a+1]=temp;
        
        }
        
         System.out.print("\n\nSorted Array\n");
        for(int z=0;z<Banquets.length;++z){

            System.out.println("ID: "+Banquets[z].toString()+"");
            System.out.println();
        }
}

}
