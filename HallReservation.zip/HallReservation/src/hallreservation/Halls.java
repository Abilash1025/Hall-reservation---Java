package hallreservation;

public class Halls 
{
    public String name,location,date;
    public int id,maxGuests,reserveId, m1, m2, m3;
    
    
    public Halls(int id, String name, String loc, int m1price, int m2price,
            int m3price, int maxg,String rDate)
    {
        this.id = id;
        this.name = name;
        this.location = loc;
        this.m1= m1price;
        this.m2= m2price;
        this.m3 = m3price;
        this.maxGuests = maxg;
        this.date=rDate;
        this.reserveId=0;
    }
    @Override
    public String toString()
    {
        return id+" Name: "+name
                    +" Location: "+location+" Maximum No.of Guests: "+maxGuests
                    +"\nThree Menu Price: \nMenu 1: "+m1+" \nMenu 2: "+m2
                    +" \nMenu 3: "+m3+"\nReservation Date : "+date
                    +" Reservation ID: "+reserveId;
    }
    
    public String toString1()
    {
        return "ID:"+id+" Name: "+name+" Location: "+location
                +"\nAvailable Reservation Date : "+date+"\n";
    }
    

}
