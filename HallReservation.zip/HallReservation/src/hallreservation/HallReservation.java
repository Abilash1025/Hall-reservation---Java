package hallreservation;

public class HallReservation 
{

    
    public static void main(String[] args) 
    {

        Callingmethods mc=new Callingmethods();
        mc.displayMenu();
        
        BanquetHalls b = new BanquetHalls();
//   b.Insertion();
    // b.bubble();

    }
}
