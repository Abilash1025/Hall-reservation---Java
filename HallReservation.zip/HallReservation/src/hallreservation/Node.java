package hallreservation;

public class Node 
{
    String data;
    Node next;
    String Location,date,customerName;
    int guests;
    
    public Node(String cName,String loc,String date,int NoOfGuests)
    {
       this.customerName=cName;
       this.Location=loc;
       this.date=date;
       this.guests=NoOfGuests;
       
       this.data=this.customerName+this.Location+this.date+this.guests;
       this.next=null;
    }
   
    
    public final void displayNode()
    {
        System.out.println("Customer Name:"+customerName+" Location:"+Location
                +" Date:"+date+" Number of Guests:"+guests+"\t");
    }
   
}
