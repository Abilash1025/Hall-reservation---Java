package hallreservation;

import java.io.IOException;
import java.util.Scanner;

public class Callingmethods 
{
    BanquetHalls bh=new BanquetHalls();
    Reservations r=new Reservations();
    WaitingList wl =new WaitingList();
    int index;

                                
    public void Confirmreservaiton()
    {
            Scanner sc=new Scanner(System.in);            
            System.out.println("Enter search data:");
            System.out.println("Location: ");
            String nLoc=sc.nextLine();
            System.out.println("Reservation Date(dd/mm/yy): ");
            String nDate=sc.nextLine();       
            System.out.println("Number of Guests: ");
            int nGuests=sc.nextInt();
            
            //int index=bh.searchBHall(nLoc,nDate,nGuests);
            for(bh.first=0;bh.first<bh.length;bh.first++)
            {    
            if(bh.Banquets[bh.first].location.equals(nLoc) &&
                        bh.Banquets[bh.first].date.equals(nDate) &&
                        bh.Banquets[bh.first].maxGuests<=nGuests &&
                        bh.Banquets[bh.first].reserveId==0)
                { 
                    System.out.println("Available Banquet Hall:\n"+bh.Banquets[bh.first].toString1());
                    index=bh.first;
                }
            }
            if(bh.Banquets[index].reserveId>0)
            {
                System.out.println("There is no banquet hall available "
                        + "at the moment.");
            }
            else
            {
            Scanner sc1=new Scanner(System.in);  
            System.out.println("IF you want toReserve Banquet Hall enter Yes if you want to wait in waitinglis type No?\nEnter Yes or No: ");
            String action=sc1.nextLine();
            
                    switch (action) 
                    {
                    case "Yes":
                        {
                            bh.SetReserveid(index);
                            int id=bh.Banquets[index].id;
                                    
                            System.out.println("__________________________________");
                            System.out.println("Enter your details:");
                            System.out.println("Customer Name: ");   
                            String cName=sc1.nextLine();
                            System.out.println("Contact Number:");
                            String num=sc1.nextLine();
                            System.out.println("Mail Address:");
                            String mail=sc1.nextLine(); 
                            
                            r.enqueue(cName,num,mail,nLoc,nDate,nGuests,id);
                            
                            System.out.println("__________________________________");
                            break;
                            
                        }
                    case "No":
                        {
                            System.out.println("Enter your details:");
                            System.out.println("Customer Name: ");   
                            String cName=sc1.nextLine();                           
                            String tempName=cName;
                            String tempLoc=nLoc;
                            String tempDate=nDate;
                            int tempGuests=nGuests;
                            wl.enqueue(tempName, tempLoc, tempDate, tempGuests);
                            System.out.println("\nDetails are added to the waiting list.");
                            System.out.println("__________________________________");
                            break;
                        }
                    }
            }
     }
    
    public void displayMenu()
     {
         //try {
        Scanner sc=new Scanner(System.in);
        
        int action=Menulist();
        
        switch(action)
        {

            
            case 1:
                bh.displayQueue();
                exitApp();
                break;
            case 2:
                System.out.println("Enter search details: ");
                Confirmreservaiton();
                exitApp();
                break;
              
            case 3:
                
                System.out.println("Enter new reservation details: ");
                
                Scanner sc1=new Scanner(System.in);
                System.out.println("Enter Old Customer Name:");
                String cName=sc.nextLine();
                System.out.println("Enter Reserved Banquet Hall ID:");
                int id=sc.nextInt();
                r.dequeue(cName,id);
                System.out.println("---------Reservations are Successfully Deleted------------");
                System.out.println("Banquet Hall Id:");
                int id1=sc.nextInt();
                System.out.println("Customer Name:");
                String Name=sc1.nextLine();
                System.out.println("Location:");
                String loc=sc1.nextLine();
                System.out.println("Reservation Date(dd/mm/yy):");
                String date=sc1.nextLine();
                System.out.println("Number of guests:");
                int guests=sc1.nextInt();
                wl.enqueue(Name,loc,date,guests);
                exitApp();
                break;
                
            case 4: 
                System.out.println("Enter Customer Name:");
                String cname=sc.nextLine();
                System.out.println("Enter Banquet Hall :");
                int id0=sc.nextInt();
                r.dequeue(cname, id0);
                exitApp();               
                break;
              
            case 5:
                wl.displayList();
                exitApp();
                break;
            case 6:
                r.displayQueue();
                exitApp();
                break;
            case 7:
                bh.avaiBanquetH();
                exitApp();
                break;
            default:
                System.out.println("Invalid number");
                break;
        }
                //}catch(Exception e){
            	  //     System.out.println("The Input are not match to the System, Please try again");
        //}
}
    
    public void exitApp()
     {
        Scanner sc=new Scanner(System.in);            
        System.out.println("Do you want to continue?\n Enter Yes or No:");
        String reply=sc.nextLine();
        switch (reply) {
            case "No":
                System.exit(0);
                break;
            case "Yes":
                displayMenu();
                break;
        }
     }
    
    public int Menulist()
    {
        System.out.println("\n1.Show all banquet halls : "
                + "\n2.Searching a Banquet Hall : "
                + "\n3.Change reservation details  : "
                + "\n4.Delete reservations: "
                + "\n5.Display waiting list"
                + "\n6.Display reservation details:"
                + "\n7.Available Banquet Halls:");
        Scanner sc=new Scanner(System.in);
        int action=sc.nextInt();
        return action;
    }
    
    
}

    
    
