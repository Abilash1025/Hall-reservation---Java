package hallreservation;

import java.util.Scanner;

public class WaitingList 
{
    Node first,last;
    
    public WaitingList()
    {
        this.first=this.last=null;
    }
    public int size() 
    { 
        // if list is not empty 
       if (this.first!=null) 
        { 
            
            Node temp = this.first; 
            int len = 0; 
            while (temp != null) { 
                len++; 
                temp = temp.next; 
            } 
            System.out.println(len);
            return len; 
        } 
        return 0; 
     } 
    public void enqueue(String cName,String loc,String date,int guests)
    {               
        
        Node temp=new Node(cName,loc,date,guests);
        
        if(this.last==null)
        {
            this.first=this.last=temp;
            return;
        }
        this.last.next=temp;
        this.last=temp;
        
    }
    
    Node dequeue()
    {
        if(this.first==null)
            return null;
        
        Node temp=this.first;
        this.first=this.first.next;
        
        if(this.first==null)
            this.last=null;
        return temp;         
    }
    void deleteNode(int position) 
    { 
        // If linked list is empty 
        if (this.first == null) 
            return; 
  
        // Store head node 
        Node temp = this.first; 
  
        // If head needs to be removed 
        if (position == 0) 
        { 
            this.first = temp.next;   // Change head 
            return; 
        } 
  
        // Find previous node of the node to be deleted 
        for (int i=0; temp!=null && i<position-1; i++) 
            temp = temp.next; 
  
        // If position is more than number of ndoes 
        if (temp == null || temp.next == null) 
            return; 
  
        // Node temp->next is the node to be deleted 
        // Store pointer to the next of node to be deleted 
        Node next = temp.next.next; 
  
        temp.next = next;  // Unlink the deleted node from list 
    }
    
    public void displayList()
    {
        if(this.first!=null)
        {
            Node current=first;
            while(current!=null)
            {
                current.displayNode();
                current=current.next;
            }
        }
        else
        {
            System.out.println("The list is empty");
        }
    }
}
    
    
